const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const pty = require("node-pty");
const { execSync, exec } = require("child_process");

const app = express();

const fs = require('fs');
const path = require('path');
const SETTINGS_FILE = path.join(__dirname, 'settings.json');

function readSettings() {
  try {
    const raw = fs.readFileSync(SETTINGS_FILE);
    return JSON.parse(raw);
  } catch (e) {
    return { panel_name: 'Ubuntu Cockpit', theme: 'white', button_color: 'blue' };
  }
}

function writeSettings(obj) {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(obj, null, 2));
}

// Settings API: get and update
app.get('/api/settings', (req, res) => {
  res.json(readSettings());
});

app.post('/api/settings', express.json(), (req, res) => {
  const body = req.body || {};
  const s = readSettings();
  if (body.panel_name !== undefined) s.panel_name = String(body.panel_name).slice(0, 200);
  if (body.theme !== undefined) s.theme = String(body.theme);
  if (body.button_color !== undefined) s.button_color = String(body.button_color);
  writeSettings(s);
  res.json({ success: true, settings: s });
});

const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

// Ensure container exists
function ensureContainer() {
  try {
    execSync("docker inspect ubuntu-vps");
  } catch {
    console.log("📦 Creating persistent Ubuntu container...");
    execSync(
      "docker run -dit --name ubuntu-vps -v ubuntu_data:/root ubuntu:22.04 bash"
    );
  }
}
ensureContainer();

// ---- API for system stats ----
app.get("/api/stats", (req, res) => {
  exec(
    "docker exec ubuntu-vps sh -c \"free -m | awk 'NR==2{printf '{\\\"ram\\\":%s,\\\"used\\\":%s}', $2,$3}'\"",
    (err, ramOut) => {
      exec(
        "docker exec ubuntu-vps sh -c \"df -h / | awk 'NR==2{printf '{\\\"disk\\\":\\\"%s\\\",\\\"used\\\":\\\"%s\\\"}', $2,$3}'\"",
        (err2, diskOut) => {
          res.json({
            ram: JSON.parse(ramOut || "{}"),
            disk: JSON.parse(diskOut || "{}"),
          });
        }
      );
    }
  );
});

// ---- Console with xterm ----
io.on("connection", (socket) => {
  console.log("Client connected");

  const ptyProcess = pty.spawn("docker", ["exec", "-it", "ubuntu-vps", "bash"], {
    name: "xterm-color",
    cols: 80,
    rows: 30,
    env: process.env,
  });

  ptyProcess.on("data", (data) => socket.emit("output", data));

  socket.on("input", (data) => ptyProcess.write(data));

  socket.on("disconnect", () => {
    console.log("Client disconnected");
    ptyProcess.kill();
  });
});

server.listen(3000, () => {
  console.log("🚀 Persistent Cockpit-style VPS Console running at http://localhost:3000");
});
