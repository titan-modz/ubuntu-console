const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const pty = require("node-pty");
const { execSync, exec } = require("child_process");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

// Ensure container exists
function ensureContainer() {
  try {
    execSync("docker inspect ubuntu-vps");
  } catch {
    console.log("📦 Creating persistent Ubuntu container...");
    execSync(
      "docker run -dit --name ubuntu-vps -v ubuntu_data:/root ubuntu:22.04 bash"
    );
  }
}
ensureContainer();

// ---- API for system stats ----
app.get("/api/stats", (req, res) => {
  exec(
    "docker exec ubuntu-vps sh -c \"free -m | awk 'NR==2{printf '{\\\"ram\\\":%s,\\\"used\\\":%s}', $2,$3}'\"",
    (err, ramOut) => {
      exec(
        "docker exec ubuntu-vps sh -c \"df -h / | awk 'NR==2{printf '{\\\"disk\\\":\\\"%s\\\",\\\"used\\\":\\\"%s\\\"}', $2,$3}'\"",
        (err2, diskOut) => {
          res.json({
            ram: JSON.parse(ramOut || "{}"),
            disk: JSON.parse(diskOut || "{}"),
          });
        }
      );
    }
  );
});

// ---- Console with xterm ----
io.on("connection", (socket) => {
  console.log("Client connected");

  const ptyProcess = pty.spawn("docker", ["exec", "-it", "ubuntu-vps", "bash"], {
    name: "xterm-color",
    cols: 80,
    rows: 30,
    env: process.env,
  });

  ptyProcess.on("data", (data) => socket.emit("output", data));

  socket.on("input", (data) => ptyProcess.write(data));

  socket.on("disconnect", () => {
    console.log("Client disconnected");
    ptyProcess.kill();
  });
});

server.listen(3000, () => {
  console.log("🚀 Persistent Cockpit-style VPS Console running at http://localhost:3000");
});
